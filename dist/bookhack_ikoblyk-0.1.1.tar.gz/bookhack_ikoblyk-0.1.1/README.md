# Bookhack

Tool for automated downloading of books from 'Culture of Ukraine' library.


## Installation

Use [docker-compose](https://docs.docker.com/compose/) to set up the environment and install the package.

```bash
docker-compose up
```

## Usage
When container starts you will be asked to enter the book url 

#####Make sure you enter a valid url
```
paste a valid url: 
```


## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)
   d7b75cd5b2f1 e587ff2389f9 aa61a9863d2d 82b99c0ad8db
   
   